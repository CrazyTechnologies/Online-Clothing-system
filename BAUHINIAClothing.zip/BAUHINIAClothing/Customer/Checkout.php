<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/nav.css">
    <link rel="stylesheet" href="css/checkout.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div>
        <div>
            <nav>
                <input type="checkbox" id="check">
                <label for="check" class="checkbtn">
                    <i class="fa fa-navicon"></i>
                </label>
                <img src="../images/logo.png" style="width: 200px; height: 70px;filter:brightness(55%)">
                <ul class="nav__list">
                    <li class="active" ><a href="Customerindex.php?customer_id=<?php echo $customer_id; ?>">Home</a></li>
                    <li ><a href="Men.php?customer_id=<?php echo $customer_id; ?>" >Men's Wear</a></li>
                    <li ><a href="Women.php?customer_id=<?php echo $customer_id; ?>" >Women's Wear</a></li>
                    <li ><a href="Kid.php?customer_id=<?php echo $customer_id; ?>" >Kid's Wear</a></li>
                    <li ><a href="cart.php?customer_id=<?php echo $customer_id; ?>  " ><img src="../images/cart.png" style="width: 25px;height: 25px; padding-top: 10px;"></a></li>
                    <li class="nav__item">
                        <a href="#profile" id="profileButton"><img src="../images/profile.png" style="width: 25px; height: 25px; padding-top: 10px;"></a>
                        <div id="profile" class="nav_dropdown">
                        <a href="orders.php?customer_id=<?php echo $customer_id; ?>">Orders</a>
                            <a href="Login.php" id="logout">Log Out</a>
                            <a href=""></a>
                        </div>
                    </li>
                </ul>
            </nav>
            <hr>
        </div>

        <div class="status">
            <input type="checkbox" class="statusconfirm" disabled checked>
            <lable>Shopping Cart</lable> 
            <input type="checkbox"class="statusconfirm"disabled >
            <lable>Check out</lable>
            <input type="checkbox"class="statusconfirm"disabled>
            <lable>Confirm Order</lable>          
        </div>

        <div class="cart-container">
            <h2>Shipping</h2>
            <br>
            <hr style="width:700px;"><br>
            <div class="center">
                <form method="POST" action="inc/Checkout.php" onsubmit="return validateForm()" name="register" id="checkoutForm">
                <?php
                include('inc/security.php');

                $customer_id = isset($_GET['customer_id']) ? $_GET['customer_id'] : null;
                $sub_total = isset($_GET['subtotal']) ? $_GET['subtotal'] : 0.00;
                $productDetails = isset($_GET['product_details']) ? json_decode($_GET['product_details'], true) : array();  // Initialize $productDetails as an empty array if not set
                
                // Fetch customer details from the database
                $customer_query = "SELECT * FROM customer WHERE Customer_ID = '$customer_id'";
                $customer_result = mysqli_query($connection, $customer_query);
                
            
                // Add hidden input fields for customer ID, subtotal, and product details
                echo '<input type="hidden" name="customer_id" value="' . $customer_id . '">';
                echo '<input type="hidden" name="subtotal" value="' . $sub_total . '">';
                echo '<input type="hidden" name="product_details" value="' . htmlspecialchars(json_encode($productDetails), ENT_QUOTES, 'UTF-8') . '">';
            
                if ($customer_result && mysqli_num_rows($customer_result) > 0) {
                    $customer_details = mysqli_fetch_assoc($customer_result);

                    // Extract customer details
                    $first_name = $customer_details['First_Name'];
                    $last_name = $customer_details['Last_Name'];
                    $address = $customer_details['Address'];
                    $email = $customer_details['Email'];
                    $num1 = $customer_details['Contact_Num1'];
                    $num2 = $customer_details['Contact_Num2'];

                } else {
                    echo '<p>Error retrieving customer details.</p>';
                }
                ?>
                <input type="hidden" name="customer_id" value="<?php echo $customer_id; ?>">
                <div class="row1">
                    <div class="col3">First Name
                        <div class="col3"><input type="text" required placeholder="Enter first name" name="First_Name" value="<?php echo $first_name; ?>"></div>
                    </div>
                    <div class="col3">Last Name
                        <div class="col3"><input type="text" required placeholder="Enter last name" name="Last_Name" value="<?php echo $last_name; ?>"></div>
                    </div>
                </div>
                <div class="row1">
                    <div class="col1">Address</div>
                </div>
                <div class="row1">
                    <div class="col1"><input type="text" required class="address" placeholder="Enter address" name="address" value="<?php echo $address; ?>"></div>
                </div>
                <div class="row1">
                    <div class="col1">Email Address</div>
                </div>
                <div class="row1">
                    <div class="col1"><input type="text" required placeholder="Enter email address" class="email" name="email" id="email" value="<?php echo $email; ?>"></div>
                </div>
                <div class="row1">
                    <div class="col1">Phone numbers</div>
                </div>
                <div class="row1">
                    <div class="col1">
                        1. <input type="text" required placeholder="Enter phone number" id="phone1" name="phone1"value="<?php echo $num1; ?>">
                        2. <input type="text" required placeholder="Enter phone number" id="phone2" name="phone2" value="<?php echo $num2; ?>">
                    </div>
                </div>
                <input type="hidden" name="subtotal" value="<?php echo $sub_total; ?>">
                
                </form>
            </div>

            <!--Related product-->
            <br>
            <br>
            <div class="selected-products">
        <h2>Selected Products</h2>
        <br>
        <hr style="width: 700px;"><br>

        <?php
        // Retrieve selected product details from the URL
        $productDetails = isset($_GET['product_details']) ? json_decode($_GET['product_details'], true) : array();

        if (!empty($productDetails)) {
            foreach ($productDetails as $productDetail) {
                $productId = $productDetail['productId'];
                $quantity = $productDetail['quantity'];

                // Display product details in a card
                echo '<div class="cart-item">';
                echo '<div class="product-details">';
                echo '<p><strong>Product ID:</strong> ' . $productId . '</p>';
                echo '<p><strong>Quantity:</strong> ' . $quantity . '</p>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo '<p>No products selected.</p>';
        }
        ?>
    </div>

    <div id="checkout-details" class="col2" style="margin-top: 70px;">
        <div>
        </div>
    </div>



         <!-- Checkout details section -->
         <div id="checkout-details" class="col2"style="margin-top:70px;">
                <div>
                    <h1 style="text-align:center;">Checkout</h1>
                        <hr><br>
                        <p style="padding:10px;">Total: Rs. <span id="subTotal"><?php echo number_format($sub_total, 2); ?></span></p><br>
                        <button onclick="checkout()" class="checkoutbtn">Checkout</button>
                </div>
                <br>
            <br><br>
            <h3>Payment Method</h3>
            <br>
            <input class="check" type="checkbox" checked disabled><lable style="margin-left:10px;">Cash on delivery</lable>
            </div>
        </div>

    </div>
    <script>
    function confirmCheckout() {
        // Display a confirmation dialog
        var confirmation = confirm('Are you sure you want to proceed with the checkout?');

        // If the user confirms, submit the form
        if (confirmation) {
            document.register.submit();
        }
    }

    function checkout() {
        // Call the confirmCheckout function instead of submitting the form directly
        confirmCheckout();
        var url = 'confirmation.php?customer_id=' + customerId +
            '&subtotal=' + subtotal +
            '&product_details=' + JSON.stringify(productDetails);
window.location.href = url;

    }
</script>
</body>
</html>