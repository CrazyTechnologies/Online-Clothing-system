<?php

// Check if the customer_id is present in the URL
if (!isset($_GET['customer_id']) || empty($_GET['customer_id'])) {
    // Redirect to the login page
    header("Location: Login.php");
    exit();
}

// Retrieve the customer_id from the URL
$customer_id = $_GET['customer_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kid's Wear</title>
    <link rel="stylesheet" href="../css/nav.css">
    <link rel="stylesheet" href="../css/footer.css">  
    <link rel="stylesheet" href="../css/Home.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/Search.css">
</head>
<body>

    <div>
        <div>
            <nav>
                    <input type="checkbox" id="check">
                    <label for="check" class="checkbtn">
                        <i class="fa fa-navicon"></i>
                    </label>
                    <img src="../images/logo.png" style="width: 200px; height: 70px;filter:brightness(55%)">
                    <ul class="nav__list">
                        <li class="active" ><a href="Customerindex.php?customer_id=<?php echo $customer_id; ?>">Home</a></li>
                        <li ><a href="Men.php?customer_id=<?php echo $customer_id; ?>">Men's Wear</a></li>
                        <li ><a href="Women.php?customer_id=<?php echo $customer_id; ?>" >Women's Wear</a></li>
                        <li ><a href="Kid.php?customer_id=<?php echo $customer_id; ?>"  class="active" >Kid's Wear</a></li>
                    <!-- <li ><a href="index.php" >Gifts</a></li>
                        <li ><a href="index.php" >Offers</a></li>-->

                    <!-- <li class="nav__item">
                        <a href="#lang" class="nav__link">
                            <img src="images/lan.png" style="width: 25px;height: 25px; padding-top: 10px;">
                        </a>
                        <div class="dropdown" id="google_translate_element">
                        <a href="#" onclick="changeLanguage('en')">English</a>
                            <a href="#" onclick="changeLanguage('ta')">Tamil</a>
                            <a href="#" onclick="changeLanguage('si')">Sinhala</a>
                        </div>
                    </li>-->
                    
                        <li >
                            <a href="cart.php?customer_id=<?php echo $customer_id; ?>" >
                                <img src="../images/cart.png" style="width: 25px;height: 25px; padding-top: 10px;">
                            </a>
                        </li>
                        <li class="nav__item">
                            <a href="#profile" id="profileButton">
                                <img src="../images/profile.png" style="width: 25px; height: 25px; padding-top: 10px;">
                            </a>
                            <div id="profile" class="nav_dropdown">
                            <a href="orders.php?customer_id=<?php echo $customer_id; ?>">Orders</a>
                                <a href="Login.php" id="logout">Log Out</a>
                                <a href=""></a>
                            </div>
                        </li>
                    </ul>
            </nav>
            <hr>
        </div> 
         
        <!-- Dresses -->
        <div class="Arrivals">
        <div class="search-container">
                <input type="text" name="search" class="search" placeholder="Search by name">
                <button onclick="searchProducts()" class="Searchbtn">Search</button>
            </div>
            <div class="row1">
            <?php
                include('inc/security.php');

                //function to fetch product data from the database
                function getProducts($connection) {
                    $products = array(); // Initialize an empty array to store product data

                    //Query to fetch products
                    $query = "SELECT * FROM product WHERE Category='Kids'";
                    $result = mysqli_query($connection, $query);

                    // Check if the query was successful
                    if ($result) {
                        // Fetch data as an associative array
                        while ($row = mysqli_fetch_assoc($result)) {
                            // Convert BLOB image data to base64 encoding
                            $row['Image'] = base64_encode($row['Image']);
                            $products[] = $row;
                        }
                        // Free the result set
                        mysqli_free_result($result);
                    } else {
                        echo 'Query failed: ' . mysqli_error($connection);
                        // Handle query error appropriately
                    }

                    return $products;
                }

                // Fetch product data from the database using the existing connection ($connection)
                $products = getProducts($connection);

                // Loop through products and generate cards
                foreach ($products as $product) {
                    echo '<div class="col3">';
                    echo '<a href="ProductDetails.php?customer_id=' . $customer_id . '&product_id=' . $product['Product_ID'] . '" class="card-link" style="text-decoration:none;">';
                    echo '<div class="cards" style="width: 18rem;">';
                    // Decode base64 and display the image
                    echo '<img src="data:image/jpeg;base64,' . $product["Image"] . '" alt="...">';
                    echo '<div class="cardbody">';
                    echo '<h4 class="cardtitle">' . $product["Product_Name"] . '</h4>';
                    echo '<p class="cardtext">Rs. ' . $product["Price"] . ' <img src="../images/Arrow.png" alt="Arrow" class="arrow"></p>';
                    echo '</div>';
                    echo '</div>';
                    echo '</a>';
                    echo '</div>';
                }
            ?>
        </div>        
    </div>

    <!--Footer-->
    <div class="Footer">
        <div class="left">
            <img src="../images/logo.png" style="width: 200px; height: 70px; margin-top: 15px;  ">
            <p>
                Complete your style with awesome clothes from us.
                <br><br>
                <a href="https://web.facebook.com/?_rdc=1&_rdr"><img src="../images/faceboook .png" class="social"></a>   
                <a href="https://www.instagram.com/accounts/login/"><img src="../images/instagram.gif"  class="social"></a>
                <a href="https://twitter.com/"><img src="../images/Twiter.png"  class="social"></a>
                <a href="https://www.linkedin.com/"><img src="../images/Linkedin.png"  class="social"></a>           
            </p>
        </div>

        <div class="right">
            <table>
                <tr>
                    <td>
                        <th>Company</th>
                    </td>
                    <td>
                        <th>Quick Links</th>
                    </td>
                    <td>
                        <th>Legal</th>
                    </td>
                </tr>

                <tr>
                    <td>
                        <th><a href="">About Us</a></th>
                    </td>
                    <td>
                        <th><a href="">Share Location</a></th>
                    </td>
                    <td> 
                        <th><a href="">Terms & Condition</a></th>
                    </td>
                </tr>

                <tr>
                    <td>
                        <th><a href="">Contact Us</a></th>
                    </td>
                    <td>
                        <th><a href="">Order Tracking</a></th>
                    </td>
                    <td> 
                        <th><a href="">Privacy Policy</a></th>
                    </td>
                </tr>

                <tr>
                    <td>
                        <th><a href="">Support</a></th>
                    </td>
                    <td>
                        <th><a href="">Size Guide</a></th>
                    </td>              
                </tr>

                <tr>
                    <td>
                        <th><a href="">Careers</a></th>
                    </td>
                    <td>
                        <th><a href="">FAQs</a></th>
                    </td>
                </tr>

            </table>
        </div>

        <div class="copy">
            <p> Copyright@BAUHINIA2022</p>
        </div>
    </div>
</body>
</html>