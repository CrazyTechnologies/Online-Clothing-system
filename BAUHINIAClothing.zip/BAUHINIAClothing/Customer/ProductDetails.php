<?php


// Check if the customer_id is present in the URL
if (!isset($_GET['customer_id']) || empty($_GET['customer_id'])) {
    // Redirect to the login page
    header("Location: Login.php");
    exit();
}

// Retrieve the customer_id from the URL
$customer_id = $_GET['customer_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details</title>
    <link rel="stylesheet" href="../css/nav.css">
    <link rel="stylesheet" href="../css/footer.css">  
    <link rel="stylesheet" href="../css/Home.css">
    <link rel="stylesheet" href="css/images.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

    <div>
        <div>
            <nav>
                <input type="checkbox" id="check">
                <label for="check" class="checkbtn">
                    <i class="fa fa-navicon"></i>
                </label>
                <img src="../images/logo.png" style="width: 200px; height: 70px;filter:brightness(55%)">
                <ul class="nav__list">
                    <li class="active" ><a href="Customerindex.php?customer_id=<?php echo $customer_id; ?>">Home</a></li>
                    <li ><a href="Men.php?customer_id=<?php echo $customer_id; ?>" >Men's Wear</a></li>
                    <li ><a href="Women.php?customer_id=<?php echo $customer_id; ?>" >Women's Wear</a></li>
                    <li ><a href="Kid.php?customer_id=<?php echo $customer_id; ?>" >Kid's Wear</a></li>
                    <li ><a href="cart.php?customer_id=<?php echo $customer_id; ?>  " ><img src="../images/cart.png" style="width: 25px;height: 25px; padding-top: 10px;"></a></li>
                    <li class="nav__item">
                        <a href="#profile" id="profileButton"><img src="../images/profile.png" style="width: 25px; height: 25px; padding-top: 10px;"></a>
                        <div id="profile" class="nav_dropdown">
                        <a href="orders.php?customer_id=<?php echo $customer_id; ?>">Orders</a>
                            <a href="Login.php" id="logout">Log Out</a>
                            <a href=""></a>
                        </div>
                    </li>
                </ul>
            </nav>
            <hr>
        </div>

        <!-- Product Details -->
        <div class="product-details-container">
            <?php
            include('inc/security.php');
            $customer_id = isset($_GET['customer_id']) ? $_GET['customer_id'] : null;

            // Output for debugging
            //echo 'Customer ID: ' . $customer_id . '<br>';
            // Check if product_id is set in the URL-
            if (isset($_GET['product_id'])) {
                $product_id = $_GET['product_id'];

                // Fetch product details from the database
                $query = "SELECT * FROM product WHERE Product_ID = '$product_id'";
                $result = mysqli_query($connection, $query);

                if ($result && mysqli_num_rows($result) > 0) {
                    $product = mysqli_fetch_assoc($result);
                    ?>
                    <div class="product-details">
                        <!-- Product Image and Details -->
                        <div class="product-image">
                            <img src="data:image/jpeg;base64,<?php echo base64_encode($product['Image']); ?>" alt="Product Image" class="Images">
                        </div>
                        <div class="product-info">
                            <h1><?php echo $product['Product_Name']; ?></h1>
                            <label style="font-weight:700; font-size:12px; padding:5px;">BY BAUHINIA CLOTHINGS</label>
                            <p style="margin:10px">Price: Rs. <?php echo $product['Price']; ?></p>
                            <p style="margin:10px">Available Quantity: <?php echo $product['Quantity']; ?></p>
                            <label style="margin:10px" for="quantity">Quantity:</label>
                            <input style="text-align:center; font-weight:700; margin:10px; width:40px; cursor: pointer; padding-top:5px;padding-bottom:5px;" type="number" id="quantity" value="1" min="1" onchange="updateTotal()">
                            <p style="text-align:center; font-weight:700; margin:10px">Total Price: Rs. <span id="totalPrice"><?php echo $product['Price']; ?></span></p>
                            <button class="btn" onclick="addToCart('<?php echo $product['Product_Name']; ?>', <?php echo $product['Price']; ?>, document.getElementById('quantity').value)">Add to Cart</button>
                            <button class="btn" onclick="buyNow(<?php echo $product['Product_ID']; ?>)">Buy Now</button>
                        </div>
                    </div>

                    <!-- Additional Products -->
                    <div class="additional-products">
                        <h2 style="margin:20px;">Related Products</h2>
                        <div class="row1" style="margin-bottom:15px;">
                            <?php
                            // Fetch six other products 
                            $related_query = "SELECT * FROM product WHERE Category = '{$product['Category']}' AND Product_ID  != '$product_id' LIMIT 6";
                            $related_result = mysqli_query($connection, $related_query);

                            while ($related_product = mysqli_fetch_assoc($related_result)) {
                                ?>
                                <div class="col3">
                                <a href="ProductDetails.php?customer_id=<?php echo $customer_id; ?>&product_id=<?php echo $related_product['Product_ID']; ?>" class="viewbtn">
                                    <div class="cards" style="width: 18rem;">
                                    <img src="data:image/jpeg;base64,<?php echo base64_encode($related_product['Image']); ?>" alt="Related Product" class="card-image">
                                    <p class="link">
                                    <?php echo $related_product['Product_Name']; ?><br>
                                    Price: Rs. <?php echo $related_product['Price']; ?></p>      
                                </div>
                                </a>
                            </div>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                    <script>
                        function updateTotal() {
                            var price = <?php echo $product['Price']; ?>;
                            var quantity = document.getElementById('quantity').value;
                            var totalPrice = price * quantity;
                            document.getElementById('totalPrice').innerHTML = totalPrice.toFixed(2);
                        }
                    </script>
                    <?php
                } else {
                    echo '<p>Product not found.</p>';
                }
            } else {
                echo '<p>Invalid product details.</p>';
            }
            ?>
        </div>

        <!--Footer-->
        <div class="Footer">
            <div class="left">
                <img src="../images/logo.png" style="width: 200px; height: 70px; margin-top: 15px;  ">
                <p>
                    Complete your style with awesome clothes from us.
                    <br><br>
                    <a href="https://web.facebook.com/?_rdc=1&_rdr"><img src="../images/faceboook .png" class="social"></a>   
                    <a href="https://www.instagram.com/accounts/login/"><img src="../images/instagram.gif"  class="social"></a>
                    <a href="https://twitter.com/"><img src="../images/Twiter.png"  class="social"></a>
                    <a href="https://www.linkedin.com/"><img src="../images/Linkedin.png"  class="social"></a>           
                </p>
            </div>

            <div class="right">
                <table>
                    <tr>
                        <td>
                            <th>Company</th>
                        </td>
                        <td>
                            <th>Quick Links</th>
                        </td>
                        <td>
                            <th>Legal</th>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <th><a href="">About Us</a></th>
                        </td>
                        <td>
                            <th><a href="">Share Location</a></th>
                        </td>
                        <td> 
                            <th><a href="">Terms & Condition</a></th>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <th><a href="">Contact Us</a></th>
                        </td>
                        <td>
                            <th><a href="">Order Tracking</a></th>
                        </td>
                        <td> 
                            <th><a href="">Privacy Policy</a></th>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <th><a href="">Support</a></th>
                        </td>
                        <td>
                            <th><a href="">Size Guide</a></th>
                        </td>              
                    </tr>

                    <tr>
                        <td>
                            <th><a href="">Careers</a></th>
                        </td>
                        <td>
                            <th><a href="">FAQs</a></th>
                        </td>
                    </tr>

                </table>
            </div>

            <div class="copy">
                <p> Copyright@BAUHINIA2022</p>
            </div>
        </div>

        <script>
    function addToCart(productName, price, quantity) {
        // Ask for confirmation
        var confirmAdd = confirm("Are you sure you want to add this item to the cart?");
        
        // If the user confirms, make the AJAX request
        if (confirmAdd) {
            $.ajax({
                type: "POST",
                url: "inc/addToCart.php",
                data: {
                    customer_id: <?php echo $customer_id; ?>,
                    product_id: <?php echo $product['Product_ID']; ?>,
                    product_name: productName,
                    quantity: quantity,
                    image: "<?php echo base64_encode($product['Image']); ?>",
                    total_price: price * quantity
                },
                success: function(response) {

                    alert("Successfully added to the cart");
                },
                error: function(error) {
                    console.error("Error adding to cart:", error);
                }
            });
        } else {
            
            console.log("Add to cart canceled by user");
        }
    }

    function updateTotal() {
        var price = <?php echo $product['Price']; ?>;
        var quantity = document.getElementById('quantity').value;
        var totalPrice = price * quantity;
        document.getElementById('totalPrice').innerHTML = totalPrice.toFixed(2);
    }
</script>




    </body>
    </html>
