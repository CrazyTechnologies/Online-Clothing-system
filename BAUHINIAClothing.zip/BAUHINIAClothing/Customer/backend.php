<?php

include('inc/security.php');

if ($_GET['action'] === 'products') {
    $customerId = $_GET['customer_id'];

    $sql = "SELECT Product_ID FROM cart WHERE Customer_ID = $customerId";
    $result = $conn->query($sql);

    $productIds = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $productIds[] = $row['Product_ID'];
        }
    }

    header('Content-Type: application/json');
    echo json_encode($productIds);
}

$conn->close();
?>
