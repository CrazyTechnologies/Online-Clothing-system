    <?php
    // Check if the customer_id is present in the URL
    if (!isset($_GET['customer_id']) || empty($_GET['customer_id'])) {
        header("Location: Login.php");
        exit();
    }
    // Retrieve the customer_id from the URL
    $customer_id = $_GET['customer_id'];
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Shopping Cart</title> 
        <link rel="stylesheet" href="../css/footer.css"> 
        <link rel="stylesheet" href="../css/nav.css">
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/cart.css">
    </head>
    <body>

    <div>
            <nav>
                <input type="checkbox" id="check">
                <label for="check" class="checkbtn">
                    <i class="fa fa-navicon"></i>
                </label>
                <img src="../images/logo.png" style="width: 200px; height: 70px;filter:brightness(55%)">
                <ul class="nav__list">
                    <li class="active" ><a href="Customerindex.php?customer_id=<?php echo $customer_id; ?>">Home</a></li>
                    <li ><a href="Men.php?customer_id=<?php echo $customer_id; ?>" >Men's Wear</a></li>
                    <li ><a href="Women.php?customer_id=<?php echo $customer_id; ?>" >Women's Wear</a></li>
                    <li ><a href="Kid.php?customer_id=<?php echo $customer_id; ?>" >Kid's Wear</a></li>
                    <li ><a href="cart.php?customer_id=<?php echo $customer_id; ?>" class="active"><img src="../images/cart.png" style="width: 25px;height: 25px; padding-top: 10px;"></a></li>
                    <li class="nav__item">
                        <a href="#profile" id="profileButton"><img src="../images/profile.png" style="width: 25px; height: 25px; padding-top: 10px;"></a>
                        <div id="profile" class="nav_dropdown">
                            <a href="orders.php?customer_id=<?php echo $customer_id; ?>">Orders</a>
                            <a href="Login.php" id="logout">Log Out</a>
                            <a href=""></a>
                        </div>
                    </li>
                </ul>
            </nav>
            <hr>
        </div>

        <div class="cart-container">
            <h2>Shopping Cart</h2>
            <br>
            <hr style="width:700px;"><br>

            <?php
                include('inc/security.php');
                $customer_id = isset($_GET['customer_id']) ? $_GET['customer_id'] : null;
                
               // Fetch product details from the database
                $query = "SELECT * FROM cart WHERE Customer_ID = '$customer_id'";
                $result = mysqli_query($connection, $query);

                if ($result && mysqli_num_rows($result) > 0) {
                    while ($product = mysqli_fetch_assoc($result)) {
                        // Display product details in a card
                        echo '<div class="cart-item">';
                        // Add a checkbox for product selection
                        echo '<input class="check" type="checkbox" id="selectProduct_' . $product['Product_ID'] . '" onclick="updateSubtotal()">';
                        echo '<div class="product-details">';
                        
                        // Check if the key "Price" exists before accessing it
                        $price = isset($product['Price']) ? $product['Price'] : 0;
                    
                        // Display the image if it exists
                        if (isset($product['Image'])) {
                            $imageData = base64_decode($product['Image']);
                            $imageSrc = 'data:image/png;base64,' . base64_encode($imageData);
                            echo '<img src="' . $imageSrc . '" alt="Product Image" class="product-image">';
                        }
                        echo '<p><strong>' . $product['Product_Name'] . '</strong></p>';
                        echo '<label for="quantity">Quantity:</label>';
                        echo '<input type="number" id="quantity_' . $product['Product_ID'] . '" value="' . $product['Quantity'] . '" min="1" disabled>';
                        echo '<p>Total: <span class="total" id="totalPrice_' . $product['Product_ID'] . '">' . number_format($product['Total_Price'] * $product['Quantity'], 2) . '</span></p>';                                                            
                       // Change this part
echo '<button onclick="removeFromCart(' . $product['Product_ID'] . ')" class="removebtn">Remove</button>';
                        echo '</div>';
                        echo '</div>';
                    }
                } else {
                    echo '<p>Your cart is empty.</p>';
                }
                
            ?>
            <!-- Checkout details section -->
            <div id="checkout-details" class="col2"style="margin-top:70px;">
                <div>
                    <h1 style="text-align:center;">Checkout</h1>
                        <hr><br>
                        <p style="padding:10px;">Total: Rs. <span id="subTotal">0.00</span></p><br>
                        <button onclick="checkout()" class="checkoutbtn">Checkout</button>
                </div>
                    
            </div>
        </div>

               <!--Footer-->
               <div class="Footer">
            <div class="left">
                <img src="../images/logo.png" style="width: 200px; height: 70px; margin-top: 15px;  ">
                <p>
                    Complete your style with awesome clothes from us.
                    <br><br>
                    <a href="https://web.facebook.com/?_rdc=1&_rdr"><img src="../images/faceboook .png" class="social"></a>   
                    <a href="https://www.instagram.com/accounts/login/"><img src="../images/instagram.gif"  class="social"></a>
                    <a href="https://twitter.com/"><img src="../images/Twiter.png"  class="social"></a>
                    <a href="https://www.linkedin.com/"><img src="../images/Linkedin.png"  class="social"></a>           
                </p>
            </div>

            <div class="right">
                <table>
                    <tr>
                        <td>
                            <th>Company</th>
                        </td>
                        <td>
                            <th>Quick Links</th>
                        </td>
                        <td>
                            <th>Legal</th>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <th><a href="">About Us</a></th>
                        </td>
                        <td>
                            <th><a href="">Share Location</a></th>
                        </td>
                        <td> 
                            <th><a href="">Terms & Condition</a></th>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <th><a href="">Contact Us</a></th>
                        </td>
                        <td>
                            <th><a href="">Order Tracking</a></th>
                        </td>
                        <td> 
                            <th><a href="">Privacy Policy</a></th>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <th><a href="">Support</a></th>
                        </td>
                        <td>
                            <th><a href="">Size Guide</a></th>
                        </td>              
                    </tr>

                    <tr>
                        <td>
                            <th><a href="">Careers</a></th>
                        </td>
                        <td>
                            <th><a href="">FAQs</a></th>
                        </td>
                    </tr>

                </table>
            </div>

            <div class="copy">
                <p> Copyright@BAUHINIA2022</p>
            </div>
        </div>


        <script>
        function updateSubtotal() {
            var selectedProducts = document.querySelectorAll('input[type="checkbox"]:checked');
            var subtotal = 0;

            selectedProducts.forEach(function (checkbox) {
                var productId = checkbox.id.split('_')[1];
                var totalSpan = document.getElementById('totalPrice_' + productId);
                var quantityInput = document.getElementById('quantity_' + productId);

                // Calculate and update subtotal
                subtotal += parseFloat(totalSpan.innerText.replace(',', '')) ;
            });

            // Update the subtotal in the checkout details
            document.getElementById('subTotal').innerText = subtotal.toFixed(2);
        }
</script> 
<script>
    function checkout() {
        var selectedProducts = document.querySelectorAll('input[type="checkbox"]:checked');
        var productDetails = [];

        selectedProducts.forEach(function (checkbox) {
            var productId = checkbox.id.split('_')[1];
            var quantityInput = document.getElementById('quantity_' + productId);

            // Retrieve product details
            var productDetail = {
                productId: productId,
                quantity: quantityInput.value
            };

            // Add product detail to the array
            productDetails.push(productDetail);
        });

        // Check if any product is selected
        if (productDetails.length > 0) {
            // Retrieve customer_id and subtotal
            var customerId = <?php echo $customer_id; ?>;
            var subtotal = parseFloat(document.getElementById('subTotal').innerText.replace(',', ''));

            // Construct the URL with parameters
            var url = 'checkout.php?customer_id=' + customerId +
                '&subtotal=' + subtotal +
                '&product_details=' + JSON.stringify(productDetails);

            // Redirect to checkout.php
            window.location.href = url;
        } else {
            // No product selected, show an alert or handle it accordingly
            alert('Please select at least one product before checking out.');
        }
    }
</script>
<script>
    function removeFromCart(productId) {
        // Send an AJAX request to remove the product from the cart
        $.ajax({
            type: "POST",
            url: "inc/deletecart.php",
            data: { customer_id: <?php echo $customer_id; ?>, product_id: productId },
            success: function (response) {
                // Remove the card from the page on success
                var cardToRemove = document.getElementById('selectProduct_' + productId).closest('.cart-item');
                cardToRemove.remove();

                // Update the subtotal after removal
                updateSubtotal();
            },
            error: function (error) {
                console.error("Error removing product from cart: ", error);
            }
        });
    }
</script>

 </body>
    </html>
