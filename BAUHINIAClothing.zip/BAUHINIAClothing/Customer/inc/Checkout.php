<?php
include('security.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve data from the form
    $customer_id = $_POST['customer_id'];
    $first_name = $_POST['First_Name'];
    $last_name = $_POST['Last_Name'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $phone1 = $_POST['phone1'];
    $phone2 = $_POST['phone2'];

    // Retrieve subtotal from the form (not from $_GET)
    $subtotal = isset($_POST['subtotal']) ? $_POST['subtotal'] : 0.00;

    // Get the current date
    $currentDate = date('Y-m-d');

    // Insert order details into the orders table
    $insertOrderQuery = "INSERT INTO orders (Customer_ID, First_Name, Last_Name, Address, Email, Contact_Num1, Contact_Num2, Date, Amount, PaymentMethod, Status)
                    VALUES ('$customer_id', '$first_name', '$last_name', '$address', '$email', '$phone1', '$phone2', '$currentDate', '$subtotal', 'Cash on delivery', 'Confirm')";

    $result = mysqli_query($connection, $insertOrderQuery);

    if ($result) {
        // Get the order ID of the inserted order
        $orderID = mysqli_insert_id($connection);

        // Retrieve selected product details from the URL
        $productDetails = isset($_POST['product_details']) ? json_decode($_POST['product_details'], true) : array();

        // Insert product details into the order_details table
        foreach ($productDetails as $productDetail) {
            $productId = $productDetail['productId'];
            $quantity = $productDetail['quantity'];

            $insertOrderDetailsQuery = "INSERT INTO order_detail (Order_ID, Product_ID, Quantity)
                                       VALUES ('$orderID', '$productId', '$quantity')";

            $resultOrderDetails = mysqli_query($connection, $insertOrderDetailsQuery);

            if (!$resultOrderDetails) {
                // Output detailed error for debugging
                echo '<script>alert("Error inserting order details. ' . mysqli_error($connection) . '");</script>';
            }
        }

        // Remove purchased items from the cart
        foreach ($productDetails as $productDetail) {
            $productId = $productDetail['productId'];
            $deleteCartItemQuery = "DELETE FROM cart WHERE Customer_ID='$customer_id' AND Product_ID='$productId'";
            mysqli_query($connection, $deleteCartItemQuery);
        }

        echo '<script>alert("Order placed successfully!");</script>';
        echo "<script>location.href='../success.php?customer_id=$customer_id';</script>";

    } else {
        // Output detailed error for debugging
        echo '<script>alert("Error placing order. ' . mysqli_error($connection) . '");</script>';
    }

    // Close the database connection
    mysqli_close($connection);

    // Redirect to a confirmation page or back to the main page
    echo '<script>window.location.href = "confirmation.php?customer_id=' . $customer_id . '";</script>';
} else {
    echo '<script>alert("Invalid request.");</script>';
}
?>
