<?php
    include('security.php');

    if(isset($_POST['submit'])){

        $firstname = $_POST['First_Name'];
        $lastname = $_POST['Last_Name'];
        $gender = $_POST['Gender'];
        $email = $_POST['email'];
        $address = $_POST['address'];
        $num1 = $_POST['phone1'];
        $num2 = $_POST['phone2'];
        $password = $_POST['password'];
        $confirm_password = $_POST['confirmpassword'];

        // Check if passwords match
        if ($password != $confirm_password) {
            echo '<script>alert("Passwords do not match.");</script>';
            echo '<script>location.href="../signup.php";</script>';
            exit();
        }

        // Check  phone numbers 
        if ($num1 === $num2) {
            echo '<script>alert("Phone numbers can not be same");</script>';
            echo '<script>location.href="../signup.php";</script>';
            exit();
        }
        
        // Hash the password before storing it in the database
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Check if the email already exists in the database
        $check_staff_id_query = "SELECT * FROM customer WHERE Email = '{$email}'";
        $check_staff_id_result = mysqli_query($connection, $check_staff_id_query);

        if (mysqli_num_rows($check_staff_id_result) > 0) {
            // Email already exists
            echo '<script>alert("Email already exists.");</script>';
            echo '<script>location.href="../signup.php";</script>';
            exit();
        }
        
        // Email don't exist, proceed with insertion
        $query = "INSERT INTO customer(`First_Name`, `Last_Name`, `Gender`, `Email`, `Address`, `Contact_Num1`, `Contact_Num2`, `Password`)
          VALUES ('{$firstname}', '{$lastname}', '{$gender}', '{$email}', '{$address}', '{$num1}', '{$num2}', '{$hashed_password}')";

        mysqli_query($connection, $query);


        echo '<script>alert("Signup successful.");</script>';
        echo '<script>location.href="../Login.php";</script>';
        exit();
    } 
    else {
        echo '<script>alert("Invalid form submission.");</script>';
        echo '<script>location.href="../signup.php";</script>';
        exit();
    }
?>
