<?php
include('security.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
    $customer_id = mysqli_real_escape_string($connection, $_POST['customer_id']);
    $product_id = mysqli_real_escape_string($connection, $_POST['product_id']);
    $product_name = mysqli_real_escape_string($connection, $_POST['product_name']);
    $quantity = mysqli_real_escape_string($connection, $_POST['quantity']);
    $image = mysqli_real_escape_string($connection, $_POST['image']);
    $total_price = mysqli_real_escape_string($connection, $_POST['total_price']);

    // Insert data into the cart table
    $insert_query = "INSERT INTO cart (Customer_ID, Product_ID, Product_Name, Quantity, Total_Price, Image) 
                     VALUES ('$customer_id', '$product_id', '$product_name', '$quantity', '$total_price', '$image')";

    $insert_result = mysqli_query($connection, $insert_query);

    if ($insert_result) {
        echo "Item added to the cart successfully!";
    } else {
        echo "Error adding item to the cart: " . mysqli_error($connection);
    }
} else {
    echo "Invalid request method!";
}
?>
