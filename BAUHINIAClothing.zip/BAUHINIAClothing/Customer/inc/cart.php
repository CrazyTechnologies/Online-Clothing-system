<?php

include('security.php');

if ($_GET['action'] === 'remove') {
    // The logic to remove the product from the cart
    $customerId = $_GET['customer_id'];
    $productId = $_GET['product_id'];

    $sql = "DELETE FROM cart WHERE Customer_ID  = $customerId AND Product_ID = $productId";
    $conn->query($sql);
} else {
    //The logic to fetch the products for the given customer ID
    $customerId = $_GET['Customer_ID'];

    $sql = "SELECT * FROM cart WHERE Customer_ID = $customerId";
    $result = $conn->query($sql);

    $products = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $products[] = array(
                'id' => $row['Product_ID'],
                'name' => $row['Product_Name'],
                'price' => $row['Total_Price'],
                'quantity' => $row['Quantity']
            );
        }
    }

    // Return the products as JSON
    header('Content-Type: application/json');
    echo json_encode($products);
}

$conn->close();
?>
