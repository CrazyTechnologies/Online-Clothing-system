<?php
include('security.php');

if (isset($_POST['login_btn']))
{
    $email = $_POST['Email'];
    $password = $_POST['Password'];

    $query = "SELECT * FROM customer WHERE Email ='$email' LIMIT 1";
    $query_run = mysqli_query($connection, $query);

    if (!$query_run) 
    {
        
        echo 'Error executing the query: ' . mysqli_error($connection);
    } 
    else 
    {
        $userTypes = mysqli_fetch_assoc($query_run);

        if ($userTypes) // Check if user with given email exists
        {
            $hashed_password = $userTypes['Password'];

            // Verify the hashed password
            if (password_verify($password, $hashed_password))
            {
                // Password is correct  
                session_start();
                $_SESSION['email'] = $email;

                // Fetch customer_id from the result
                $customer_id = $userTypes['Customer_ID'];

                // Redirect to Index.php with customer_id in the URL
                header("Location:../Customerindex.php?customer_id=$customer_id");
                exit();                
            } 
            else 
            {
                // Password is incorrect
                session_start();
                $_SESSION['status'] = "Email / Password is Invalid";
                echo '<script>alert("Email / Password is Invalid.");</script>';
                echo '<script>location.href="../Login.php";</script>';
                exit();
            }
        }
        else
        {
            // User does not exist with the given email
            session_start();
            $_SESSION['status'] = "Email / Password is Invalid";
            echo '<script>alert("Email / Password is Invalid.");</script>';
            echo '<script>location.href="../Login.php";</script>';
            exit();
        }
    } 
}
?>
