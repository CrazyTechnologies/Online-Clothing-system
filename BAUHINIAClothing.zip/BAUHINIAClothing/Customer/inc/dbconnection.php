<?php

$connection = mysqli_connect('localhost','root','','bauhinia');
if (mysqli_connect_errno()){
    die('Database connection Failed'. mysqli_connect_errno());//if there db connection issue display the connection is failed and show error number
}else{
    echo "";
}

?>
