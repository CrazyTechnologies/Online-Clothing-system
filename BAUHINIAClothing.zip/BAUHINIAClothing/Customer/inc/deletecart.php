<?php
// inc/deletecart.php

include('security.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customer_id = isset($_POST['customer_id']) ? $_POST['customer_id'] : null;
    $product_id = isset($_POST['product_id']) ? $_POST['product_id'] : null;

    // Check if the customer_id and product_id are valid
    if ($customer_id && $product_id) {
        // Perform the database operation to remove the product from the cart
        $query = "DELETE FROM cart WHERE Customer_ID = '$customer_id' AND Product_ID = '$product_id'";
        $result = mysqli_query($connection, $query);

        if ($result) {
            // Return a success response
            echo json_encode(['success' => true]);
            exit();
        } else {
            // Return an error response
            echo json_encode(['success' => false, 'error' => mysqli_error($connection)]);
            exit();
        }
    } else {
        // Return an error response if customer_id or product_id is not provided
        echo json_encode(['success' => false, 'error' => 'Invalid parameters.']);
        exit();
    }
} else {
    // Return an error response for unsupported request methods
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
    exit();
}
?>
