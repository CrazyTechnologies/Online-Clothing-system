<?php

  include('dbconnection.php');

  session_start();

  if($connection){
    //echo "Database Connected Successfully";
  }
  else{
    header("Location: dbConnect.php");
  }

?>