// cart.js

document.addEventListener('DOMContentLoaded', function () {
    // Check if product details are provided in the URL
    const urlParams = new URLSearchParams(window.location.search);
    const productName = urlParams.get('productName');
    const price = urlParams.get('price');
    const quantity = urlParams.get('quantity');

    // If product details are provided, add them to the cart
    if (productName && price && quantity) {
        addToCart(productName, parseInt(quantity), parseFloat(price));
    }
});

// Function to add a product to the cart
function addToCart(productName, quantity, price) {
    // Calculate total price for the item
    const total = quantity * price;

    // Create a new card for the cart item
    const newCard = document.createElement("div");
    newCard.className = "cart-item";
    newCard.innerHTML = `
        <div class="item-details">
            <p><strong>${productName}</strong></p>
            <p>Price: ${price}</p>
            <label for="quantity">Quantity:</label>
            <input type="number" id="quantity" value="${quantity}" min="1" onchange="updateTotal(this, ${price})">
            <p>Total: <span class="total">${total}</span></p>
        </div>
        <div class="remove-btn">
            <button onclick="removeFromCart(this)">Remove</button>
        </div>
    `;

    
    document.getElementById("cart-body").appendChild(newCard);
    updateCheckoutDetails();
}

// Function to remove a product from the cart
function removeFromCart(button) {
    // Get the reference to the button's card and remove it
    const card = button.parentNode.parentNode;
    card.parentNode.removeChild(card);
    updateCheckoutDetails();
}

// Function to update total price when quantity is adjusted
function updateTotal(input, price) {
    const quantity = parseInt(input.value);
    const total = quantity * price;
    input.parentNode.nextElementSibling.querySelector('.total').innerText = total.toFixed(2);
    updateCheckoutDetails();
}

// Function to update checkout details
function updateCheckoutDetails() {
    const items = document.querySelectorAll('.cart-item');
    let subTotal = 0;

    items.forEach(item => {
        const total = parseFloat(item.querySelector('.total').innerText);
        subTotal += total;
    });

    // Update checkout details on the right side
    document.getElementById('subTotal').innerText = subTotal.toFixed(2);
    document.getElementById('shoppingCost').innerText = "0.00"; // Placeholder for shopping cost
}

// Function to initiate checkout
function checkout() {
    // Redirect to the checkout page or handle the checkout process
    alert("Initiating Checkout!");
}
