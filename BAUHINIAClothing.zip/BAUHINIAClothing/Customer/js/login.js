
function validateForm() {
  // Validate email
  let emailElement = document.forms["register"]["email"];
  let emailValue = emailElement.value;

  // Regular expression for a simple email format check
  let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (emailRegex.test(emailValue)) {
    // Email is in the correct format
  } else {
    emailElement.value = '';
    alert("Please enter a valid email address.");
    return false;
  }

   return true;
 }
