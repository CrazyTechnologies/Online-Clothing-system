
function validateForm() {
  // Validate email
  let emailElement = document.forms["register"]["email"];
  let emailValue = emailElement.value;

  // Regular expression for a simple email format check
  let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (emailRegex.test(emailValue)) {
    // Email is in the correct format
  } else {
    emailElement.value = '';
    alert("Please enter a valid email address.");
    return false;
  }

  // Validate phone1
  let phone1Element = document.forms["register"]["phone1"];
  let phone1Value = phone1Element.value;
  let cleanedPhone1Value = phone1Value.replace(/\D/g, '');

  if (/^\d{10}$/.test(cleanedPhone1Value)) {
    phone1Element.value = cleanedPhone1Value;
  } else {
    phone1Element.value = '';
    alert("Phone number must contain 10 digits.Check first phone number you entered.");
    return false;
  }

  // Validate phone2
  let phone2Element = document.forms["register"]["phone2"];
  let phone2Value = phone2Element.value;
  let cleanedPhone2Value = phone2Value.replace(/\D/g, '');

  if (/^\d{10}$/.test(cleanedPhone2Value)) {
    phone2Element.value = cleanedPhone2Value;
  } else {
    phone2Element.value = '';
    alert("Phone number must contain 10 digits.Check second phone number you entered.");
    return false;
  }

  // Check if phone1 and phone2 are the same
  if (cleanedPhone1Value === cleanedPhone2Value) {
    alert("Phone numbers cannot be the same.");
    return false;
  }

   // Validate password
   let passwordElement = document.forms["register"]["password"];
   let confirmPasswordElement = document.forms["register"]["confirmpassword"];
   let passwordValue = passwordElement.value;
   let confirmPasswordValue = confirmPasswordElement.value;
 
   // Check if password and confirm password match
   if (passwordValue !== confirmPasswordValue) {
     passwordElement.value = '';
     confirmPasswordElement.value = '';
     alert("Password and Confirm Password must match.");
     return false;
   }
   if (passwordValue.length < 8 || passwordValue.length > 16) {
    passwordElement.value = '';
    confirmPasswordElement.value = '';
    alert("Password should have a minimum of 8 characters and a maximum of 16 characters.");
    return false;
  }
   // Check if password contains at least one letter, one number, and one symbol
   let passwordRegex = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/;
   if (!passwordRegex.test(passwordValue)) {
     passwordElement.value = '';
     confirmPasswordElement.value = '';
     alert("Password must contain at least one letter, one number, and one symbol.");
     return false;
   }

   return true;
 }
