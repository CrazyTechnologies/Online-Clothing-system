<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders</title>
    <link rel="stylesheet" href="../css/footer.css"> 
    <link rel="stylesheet" href="../css/nav.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
       body {
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .order {
            width: 80%;
            margin: auto;
            border-collapse: collapse;
            text-align: center;
            margin-bottom: 25px;
            margin-right:100px;
        }

        .order, .th, .td {
            border: 1px solid #ddd;
        }

        .th, .td {
            padding: 12px;
        }

        .th {
            background-color: rgb(222,198,69);
        }


    </style>
</head>
<body>
    

            <div>
                <nav>
                    <input type="checkbox" id="check">
                    <label for="check" class="checkbtn">
                        <i class="fa fa-navicon"></i>
                    </label>
                    <img src="../images/logo.png" style="width: 200px; height: 70px;filter:brightness(55%)">
                    <ul class="nav__list">
                        <li class="active" ><a href="Customerindex.php?customer_id=<?php echo $customer_id; ?>">Home</a></li>
                        <li ><a href="Men.php?customer_id=<?php echo $customer_id; ?>" >Men's Wear</a></li>
                        <li ><a href="Women.php?customer_id=<?php echo $customer_id; ?>" >Women's Wear</a></li>
                        <li ><a href="Kid.php?customer_id=<?php echo $customer_id; ?>" >Kid's Wear</a></li>
                        <li ><a href="cart.php?customer_id=<?php echo $customer_id; ?>"><img src="../images/cart.png" style="width: 25px;height: 25px; padding-top: 10px;"></a></li>
                        <li class="nav__item">
                            <a href="#profile" id="profileButton"><img src="../images/profile.png" style="width: 25px; height: 25px; padding-top: 10px;"></a>
                            <div id="profile" class="nav_dropdown">
                                <a href="orders.php?customer_id=<?php echo $customer_id; ?>">Orders</a>
                                <a href="Login.php" id="logout">Log Out</a>                               
                            </div>
                        </li>
                    </ul>
                </nav>
                <hr>
            </div>

            <div id="ordersContainer">
            <h1>All the orders belong to you</h1><br>
                <table class="order">
                    <tr class="tr">
                        <th class="th">Order ID</th>
                        <th class="th">Date</th>
                        <th class="th">Amount</th>
                        <th class="th">Payment Method</th>
                        <th class="th">Status</th>
                    </tr>
                            <?php
                                include('inc/security.php');
                                $customer_id = isset($_GET['customer_id']) ? $_GET['customer_id'] : null;
                                $sql = "SELECT * FROM orders WHERE Customer_ID = $customer_id";
                                $result = $connection->query($sql);

                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<tr class=\"tr\">";
                                        echo "<td class=\"td\">" . $row['Order_ID'] . "</td>";
                                        echo "<td class=\"td\">" . $row['Date'] . "</td>";
                                        echo "<td class=\"td\">" . $row['Amount'] . "</td>";
                                        echo "<td class=\"td\">" . $row['PaymentMethod'] . "</td>";
                                        echo "<td class=\"td\">" . $row['Status'] . "</td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='5'>No orders found for this customer.</td></tr>";
                                }

                                $connection->close();
                            ?>
                        </table>
            </div>
            
            <div >
                    <!--Footer-->
                <div class="Footer">
                    <div class="left">
                        <img src="../images/logo.png" style="width: 200px; height: 70px; margin-top: 15px;  ">
                        <p>
                            Complete your style with awesome clothes from us.
                            <br><br>
                            <a href="https://web.facebook.com/?_rdc=1&_rdr"><img src="../images/faceboook .png" class="social"></a>   
                            <a href="https://www.instagram.com/accounts/login/"><img src="../images/instagram.gif"  class="social"></a>
                            <a href="https://twitter.com/"><img src="../images/Twiter.png"  class="social"></a>
                            <a href="https://www.linkedin.com/"><img src="../images/Linkedin.png"  class="social"></a>           
                        </p>
                    </div>

                    <div class="right">
                        <table>
                            <tr>
                                <td>
                                    <th>Company</th>
                                </td>
                                <td>
                                    <th>Quick Links</th>
                                </td>
                                <td>
                                    <th>Legal</th>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <th><a href="">About Us</a></th>
                                </td>
                                <td>
                                    <th><a href="">Share Location</a></th>
                                </td>
                                <td> 
                                    <th><a href="">Terms & Condition</a></th>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <th><a href="">Contact Us</a></th>
                                </td>
                                <td>
                                    <th><a href="">Order Tracking</a></th>
                                </td>
                                <td> 
                                    <th><a href="">Privacy Policy</a></th>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <th><a href="">Support</a></th>
                                </td>
                                <td>
                                    <th><a href="">Size Guide</a></th>
                                </td>              
                            </tr>

                            <tr>
                                <td>
                                    <th><a href="">Careers</a></th>
                                </td>
                                <td>
                                    <th><a href="">FAQs</a></th>
                                </td>
                            </tr>

                        </table>
                    </div>

                    <div class="copy">
                        <p> Copyright@BAUHINIA2022</p>
                    </div>
                </div>
            </div>

        
            <script>
    document.addEventListener("DOMContentLoaded", function () {
        
        var profileDropdown = document.getElementById("profile");
        var logoutLink = profileDropdown.querySelector("#logout");

        logoutLink.addEventListener("click", function (event) {
            event.preventDefault();
            // Show a confirmation dialog
            var confirmLogout = window.confirm("Are you sure you want to log out?");
            if (confirmLogout) {
                // If the user clicks "OK," redirect to the logout page
                window.location.href = "Logout.php";
            }
        });
    });
</script>
</body>
</html>