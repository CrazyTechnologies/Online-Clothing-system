<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/signup.css">
    <link rel="stylesheet" href="css/footer.css">  
    <script src="js/signupvalidation.js"></script>

</head>
<body>
    <div class="container">
        <nav>
            <div>
                <div class="nav__menu" id="nav-menu">
                    <img src="images/logo.png" style="width: 200px; height: 70px;filter:brightness(55%)">
                    <ul class="nav__list">
                        <li class="nav__item"><a href="../Index.php" class="nav__link active" >Home</a></li>
                        <li class="nav__item">
                            <a href="#lang" class="nav__link">
                                <img src="images/lan.png" style="width: 25px;height: 25px; padding-top: 10px;">
                            </a>
                            <div class="nav__dropdown" id="google_translate_element">
                              <!-- <a href="#" onclick="changeLanguage('en')">English</a>
                                <a href="#" onclick="changeLanguage('ta')">Tamil</a>
                                <a href="#" onclick="changeLanguage('si')">Sinhala</a>-->
                            </div>
                        </li>
                        <li class="nav__item"><a href="Login.php" class="nav__link" >Sign In</a></li>
                    </ul>
                </div>
                <hr>
            </div>
        </nav>
    
        <div class="center">
            <h1 >Sign Up</h1>
                <hr>
                <p>Welcome !</p>
                <form method="POST" action="inc/Signup.php" onsubmit="return validateForm()" name="register">

                <div class="row1">
                    <div class="col3">First Name
                        <div class="col3"><input type="text"required placeholder="Enter firts name"  name="First_Name"></div>
                    </div>
                    <div class="col3">Last Name
                        <div class="col3"><input type="text"required placeholder="Enter last name" name="Last_Name"></div>
                    </div>
                    <div class="col3">Gender
                        <div class="col3"><select name="Gender">
                            <option selected="selected"></option>
                            <option>Male</option>
                            <option>female</option>
                            <option>Other</option>
                            </select></div>
                    </div>
                </div>

                <div class="row1">
                    <div class="col1">Email Address</div>
                </div>

                <div class="row1">
                    <div class="col1"><input type="text"required placeholder="Enter email address" class="email" name="email" id="email"></div>
                </div>
                <div class="row1">
                    <div class="col1">Address</div>
                </div>

                <div class="row1">
                    <div class="col1"><input type="text"required class="address"  placeholder="Enter address" name="address"></div>
                </div>

                <div class="row1">
                    <div class="col1">Phone numbers</div>
                </div>

                <div class="row1">
                <div class="col1">
                        1. <input type="text" required placeholder="Enter phone number" id="phone1" name="phone1">
                        <button class="btnotp" id="otpBtn1" type="button" onclick="sendOTP('phone1')">Send OTP</button>
                        <input type="text" required placeholder="Enter OTP" id="otp1" name="otp1">
                    </div>
                </div>

                
                <div class="row1">
                    <div class="col1"> 
                        2. <input type="text" placeholder="Enter phone number" id="phone2" name="phone2" >
                        <button class="btnotp" id="otpBtn2" type="button" onclick="sendOTP('phone2')" >Send OTP</button>
                        <input type="text" placeholder="Enter OTP" id="otp2" name="otp2" >
                    </div>
                </div>

                <div class="row1">
                    <div class="col1">Password</div>
                </div>

                <div class="row1">
                    <div class="col1"><input type="password"required class="password"  placeholder="Enter password" name="password">
                    <input type="password"required class="password"  placeholder="Confirm password" name="confirmpassword"></div>
                </div>

                <input class="submit" type="Submit" Value="Submit" name="submit">
            </form>
        </div>
    
    
        <div class="Footer">
            <div class="left">
                <img src="images/logo.png" style="width: 200px; height: 70px; margin-top: 15px; filter:brightness(90%);">
            <p>
                Complete your style with awesome clothes from us.
                <br><br>
                
                <img src="images/faceboook .png" class="social">
                <img src="images/instagram.gif"  class="social">
                <img src="images/Twiter.png"  class="social">
                <img src="images/Linkedin.png"  class="social">
    
            </p>
            </div>
    
            <div class="right">
                <table>
                   <tr>
                    <td>
                        <th>Company</th>
                    </td>
                    <td>
                        <th>Quick Links</th>
                    </td>
                    <td>
                        <th>Legal</th>
                    </td>
                   </tr>
    
                   <tr>
                    <td>
                        <th><a href="">About Us</a></th>
                    </td>
                    <td>
                        <th><a href="">Share Location</a></th>
                    </td>
                    <td> 
                        <th><a href="">Terms & Condition</a></th>
                    </td>
                   </tr>
    
                   <tr>
                    <td>
                        <th><a href="">Contact Us</a></th>
                    </td>
                    <td>
                        <th><a href="">Order Tracking</a></th>
                    </td>
                    <td> 
                        <th><a href="">Privacy Policy</a></th>
                    </td>
                   </tr>
    
                   <tr>
                    <td>
                        <th><a href="">Support</a></th>
                    </td>
                    <td>
                        <th><a href="">Size Guide</a></th>
                    </td>              
                   </tr>
    
                   <tr>
                    <td>
                        <th><a href="">Careers</a></th>
                    </td>
                    <td>
                        <th><a href="">FAQs</a></th>
                    </td>
                   </tr>
    
                </table>
            </div>
    
    
            <div class="copy">
               <p> Copyright@BAUHINIA2022</p>
            </div>
        </div>
    </div>


    <script type="text/javascript">
        function googleTranslateElementInit() {
          new google.translate.TranslateElement({ pageLanguage: 'en' , includedLanguages: 'en,ta,si',}, 'google_translate_element');
        }
      </script>
      <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    
</body>
</html>