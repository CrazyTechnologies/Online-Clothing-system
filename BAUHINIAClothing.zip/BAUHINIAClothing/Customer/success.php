<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/nav.css">
    <link rel="stylesheet" href="css/success.css">
    <link rel="stylesheet" href="css/footer.css">
</head>
<body>
    <div>
        <div>
            <nav>
                <input type="checkbox" id="check">
                <label for="check" class="checkbtn">
                    <i class="fa fa-navicon"></i>
                </label>
                <img src="../images/logo.png" style="width: 200px; height: 70px;filter:brightness(55%)">
                <ul class="nav__list">
                    <li class="active" ><a href="Customerindex.php?customer_id=<?php echo $customer_id; ?>">Home</a></li>
                    <li ><a href="Men.php?customer_id=<?php echo $customer_id; ?>" >Men's Wear</a></li>
                    <li ><a href="Women.php?customer_id=<?php echo $customer_id; ?>" >Women's Wear</a></li>
                    <li ><a href="Kid.php?customer_id=<?php echo $customer_id; ?>" >Kid's Wear</a></li>
                    <li ><a href="cart.php?customer_id=<?php echo $customer_id; ?>  " ><img src="../images/cart.png" style="width: 25px;height: 25px; padding-top: 10px;"></a></li>
                    <li class="nav__item">
                        <a href="#profile" id="profileButton"><img src="../images/profile.png" style="width: 25px; height: 25px; padding-top: 10px;"></a>
                        <div id="profile" class="nav_dropdown">
                        <a href="orders.php?customer_id=<?php echo $customer_id; ?>">Orders</a>
                            <a href="Login.php" id="logout">Log Out</a>
                            <a href=""></a>
                        </div>
                    </li>
                </ul>
            </nav>
            <hr>
        </div>

        <div style="height: 340px; margin-top: 20px;align-items: center;">
            <div class="success">
                <center>Order Successful</center>
                <center><button class="btn"id="viewOrdersButton"> View Orders</button></center>
            </div>
        </div>

        <div class="Footer">
            <div class="left">
                <img src="images/logo.png" style="width: 200px; height: 70px; margin-top: 15px; filter:brightness(90%);">
            <p>
                Complete your style with awesome clothes from us.
                <br><br>
                
                <img src="images/faceboook .png" class="social">
                <img src="images/instagram.gif"  class="social">
                <img src="images/Twiter.png"  class="social">
                <img src="images/Linkedin.png"  class="social">
    
            </p>
            </div>
    
            <div class="right">
                <table>
                   <tr>
                    <td>
                        <th>Company</th>
                    </td>
                    <td>
                        <th>Quick Links</th>
                    </td>
                    <td>
                        <th>Legal</th>
                    </td>
                   </tr>
    
                   <tr>
                    <td>
                        <th><a href="">About Us</a></th>
                    </td>
                    <td>
                        <th><a href="">Share Location</a></th>
                    </td>
                    <td> 
                        <th><a href="">Terms & Condition</a></th>
                    </td>
                   </tr>
    
                   <tr>
                    <td>
                        <th><a href="">Contact Us</a></th>
                    </td>
                    <td>
                        <th><a href="">Order Tracking</a></th>
                    </td>
                    <td> 
                        <th><a href="">Privacy Policy</a></th>
                    </td>
                   </tr>
    
                   <tr>
                    <td>
                        <th><a href="">Support</a></th>
                    </td>
                    <td>
                        <th><a href="">Size Guide</a></th>
                    </td>              
                   </tr>
    
                   <tr>
                    <td>
                        <th><a href="">Careers</a></th>
                    </td>
                    <td>
                        <th><a href="">FAQs</a></th>
                    </td>
                   </tr>
    
                </table>
            </div>
    
    
            <div class="copy">
               <p> Copyright@BAUHINIA2022</p>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener("DOMContentLoaded", function () {
        // Fetch the customer_id from the URL using PHP
        <?php
            $customer_id = isset($_GET['customer_id']) ? $_GET['customer_id'] : null;
        ?>

        // Select the button by ID
        var viewOrdersButton = document.getElementById("viewOrdersButton");

        viewOrdersButton.addEventListener("click", function () {
            // Redirect to order.php with customer_id in the URL
            window.location.href = "orders.php?customer_id=<?php echo $customer_id; ?>";
        });
    });
</script>

</body>
</html>