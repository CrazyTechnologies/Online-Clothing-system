<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accounts</title>
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/footer.css">  
    <link rel="stylesheet" href="css/Accounts.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div>
    <div>
                <nav>
                    <img src="images/logo.png" style="width: 200px; height: 70px;filter:brightness(55%)">
                    <ul class="nav__list">
                        <li class="nav__item">
                            <a href="#profile" id="profileButton">
                                <img src="images/profile.png" style="width: 25px; height: 25px; padding-top: 10px;">
                            </a>
                            <div id="profile" class="nav_dropdown">
                                <a href="">Profile</a>
                                <a href="StaffLogin.php">Log Out</a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <hr>
            </div>  

        <div class="center">
            <h1 class="heading">Income Report</h1>
            <hr>
            <br>
            <form id="generateReportForm">
                <div class="row1">
                    <div class="col1">Month
                        <div class="col1"><input type="month" id="selectedMonth" required class="date"></div>
                    </div>
                </div>

                <input class="submit" type="button" value="Generate report" onclick="generateReport()" id="btnreport">
            </form>
        </div>

            <!--Footer-->
            <div class="Footer">
                <div class="left">
                    <img src="images/logo.png" style="width: 200px; height: 70px; margin-top: 15px;  ">
                <p>
                    Complete your style with awesome clothes from us.
                    <br><br>
                    <a href="https://web.facebook.com/?_rdc=1&_rdr"><img src="images/faceboook .png" class="social"></a>   
                    <a href="https://www.instagram.com/accounts/login/"><img src="images/instagram.gif"  class="social"></a>
                    <a href="https://twitter.com/"><img src="images/Twiter.png"  class="social"></a>
                    <a href="https://www.linkedin.com/"><img src="images/Linkedin.png"  class="social"></a>           
                </p>
                </div>

                <div class="right">
                    <table>
                    <tr>
                        <td>
                            <th>Company</th>
                        </td>
                        <td>
                            <th>Quick Links</th>
                        </td>
                        <td>
                            <th>Legal</th>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <th><a href="">About Us</a></th>
                        </td>
                        <td>
                            <th><a href="">Share Location</a></th>
                        </td>
                        <td> 
                            <th><a href="">Terms & Condition</a></th>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <th><a href="">Contact Us</a></th>
                        </td>
                        <td>
                            <th><a href="">Order Tracking</a></th>
                        </td>
                        <td> 
                            <th><a href="">Privacy Policy</a></th>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <th><a href="">Support</a></th>
                        </td>
                        <td>
                            <th><a href="">Size Guide</a></th>
                        </td>              
                    </tr>

                    <tr>
                        <td>
                            <th><a href="">Careers</a></th>
                        </td>
                        <td>
                            <th><a href="">FAQs</a></th>
                        </td>
                    </tr>

                    </table>
                </div>


                <div class="copy">
                <p> Copyright@BAUHINIA2022</p>
                </div>
            </div>
    </div>

    <script>
        function generateReport() {
            // Fetch the selected month from the input
            var selectedMonth = document.getElementById("selectedMonth").value;

            // Fetch report details from the server
            fetch('inc/generateFinancialReport.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ selectedMonth: selectedMonth }),
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok. Status: ' + response.status);
                }
                return response.json();
            })
            .then(data => {
                // Open the PDF in a new tab
                window.open(data.pdfUrl, '_blank');
            })
            .catch(error => {
                console.error('Error generating report:', error);
            });
        }
    </script>
     <script>
            document.addEventListener("DOMContentLoaded", function () {
            // Fetch total product quantity from the server
            fetch('inc/getquantity.php')
                .then(response => response.json())
                .then(data => {
                    // Update the product quantity in the HTML
                    const productQuantityElement = document.querySelector('.col2 #lable1');
                    if (productQuantityElement) {
                        productQuantityElement.textContent = data.totalQuantity;
                    }
                })
                .catch(error => {
                    console.error('Error fetching product quantity:', error);
                    console.log('Response status:', error.status);
                    console.log('Response text:', error.statusText);
                });

            // Fetch total orders from the server
            fetch('inc/orders.php')
                .then(response => response.json())
                .then(data => {
                    // Update the product quantity in the HTML
                    const productQuantityElement = document.querySelector('.col2 #lable2');
                    if (productQuantityElement) {
                        productQuantityElement.textContent = data.orders;
                    }
                })
                .catch(error => {
                    console.error('Error fetching product quantity:', error);
                    console.log('Response status:', error.status);
                    console.log('Response text:', error.statusText);
                });

            var profileButton = document.getElementById("profileButton");
            var profileDropdown = document.getElementById("profile");

            profileButton.addEventListener("click", function (event) {
                event.preventDefault();
                profileDropdown.classList.toggle("active");
            });
        });
    </script>
</body>
</html>
