<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory</title>
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/updateinventory.Css">
    <link rel="stylesheet" href="css/inventory.css">
    <link rel="stylesheet" href="css/footer.css">  
    <script src="script.js"></script> 
</head>
<body>
    <div class="container">
        <nav>
            <div>
                <nav>
                    <img src="images/logo.png" style="width: 200px; height: 70px;filter:brightness(55%)">
                    <ul class="nav__list">
                        <li class="nav__item">
                            <a href="#profile" id="profileButton">
                                <img src="images/profile.png" style="width: 25px; height: 25px; padding-top: 10px;">
                            </a>
                            <div id="profile" class="nav_dropdown">
                                <a href="">Profile</a>
                                <a href="StaffLogin.php">Log Out</a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <hr>
            </div> 
        </nav>
    
        <div class="center">
            <h1 >Inventory</h1>
                <hr>
                <br>
            <form action="inc/Inventory.php" method="POST" enctype="multipart/form-data">
                <div class="row1">
                    <div class="col3">Product ID
                        <div class="col3"><input type="text"required placeholder="Enter Product ID" name="Prod_ID"></div>
                    </div>
                    <div class="col3">Product Name
                        <div class="col3"><input type="text"required placeholder="Enter Product Name"  name="Prod_Name"></div>
                    </div>
                    <div class="col3">Price
                        <div class="col3"><input type="text"required placeholder="Enter Price"  name="Price"></div>
                    </div>
                </div>

                <div class="row1">
                    <div class="col3">Quantity
                        <div class="col1"><input type="text"required placeholder="Enter Quantity" name="Quantity"></div>
                    </div>
                    <div class="col3">Category
                        <div class="col3">
                            <select name="Category" class="Select">
                                <option>Men</option>
                                <option>Women</option>
                                <option> Kids</option>
                                </select>
                        </div>
                    </div>
                    <div class="col3">Image<br>
                            <input type="file" name="image" id="image" accept="image/*" required  >
                    </div>
                </div>

                <div class="row1">
 
                </div>
           
                <input class="submit" type="Submit" Value="Add" name="Addbtn">
            </form>
        </div>
        
        
        <div class="InventoryTable">
            <form>
                  <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Quantity</th>
                                <th scope="col">Category</th>
                                <th scope="col">Price</th>
                                <th scope="col">Edit</th>
                                <th scope="col">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            include('inc/security.php');
                            $sql = "SELECT * FROM product";

                            $result=mysqli_query($connection,$sql);

                            while ($row = mysqli_fetch_array($result)){

                                echo "<tr>";
                                    echo "<td>"; echo $row['Product_ID'];echo "</td>";
                                    echo "<td>"; echo $row['Product_Name'];echo "</td>";
                                    echo "<td>"; echo $row['Quantity'];echo "</td>";
                                    echo "<td>"; echo $row['Category'];echo "</td>";
                                    echo "<td>"; echo $row['Price'];echo "</td>";
                                
                                        echo "<td>";?><a href="InventroyUpdate.php?Product_ID=<?php echo $row['Product_ID'];?>"><button style="width:60px; background-color:Green; color:white; border-radius:5px; cursor:Pointer; border:none;Height:25px;" type="button" class="btn-success" name="edit">Edit</button></a>  <?php
                                        echo "</td>"; 

                                        echo "<td>";?><a href="inc/Productdelet.php?Product_ID=<?php echo $row['Product_ID'];?>"><button style="width:60px; background-color:Gray; color:white; border-radius:5px; cursor:Pointer;border:none;Height:25px;"type="button" class="btn-danger" name="delete">Delete</button></a> <?php
                                        echo "</td>"; 

                                        echo "</tr>";

                            }

                            ?>

                        </tbody>
                    </table>
            </form>
        </div>
    
        <div class="Footer">
            <div class="left">
                <img src="images/logo.png" style="width: 200px; height: 70px; margin-top: 15px; filter:brightness(90%);">
            <p>
                Complete your style with awesome clothes from us.
                <br><br>
                
                <img src="images/faceboook .png" class="social">
                <img src="images/instagram.gif"  class="social">
                <img src="images/Twiter.png"  class="social">
                <img src="images/Linkedin.png"  class="social">
    
            </p>
            </div>
    
            <div class="right">
                <table>
                   <tr>
                    <td>
                        <th>Company</th>
                    </td>
                    <td>
                        <th>Quick Links</th>
                    </td>
                    <td>
                        <th>Legal</th>
                    </td>
                   </tr>
    
                   <tr>
                    <td>
                        <th><a href="">About Us</a></th>
                    </td>
                    <td>
                        <th><a href="">Share Location</a></th>
                    </td>
                    <td> 
                        <th><a href="">Terms & Condition</a></th>
                    </td>
                   </tr>
    
                   <tr>
                    <td>
                        <th><a href="">Contact Us</a></th>
                    </td>
                    <td>
                        <th><a href="">Order Tracking</a></th>
                    </td>
                    <td> 
                        <th><a href="">Privacy Policy</a></th>
                    </td>
                   </tr>
    
                   <tr>
                    <td>
                        <th><a href="">Support</a></th>
                    </td>
                    <td>
                        <th><a href="">Size Guide</a></th>
                    </td>              
                   </tr>
    
                   <tr>
                    <td>
                        <th><a href="">Careers</a></th>
                    </td>
                    <td>
                        <th><a href="">FAQs</a></th>
                    </td>
                   </tr>
    
                </table>
            </div>
    
    
            <div class="copy">
               <p> Copyright@BAUHINIA2022</p>
            </div>
        </div>
    </div>
    <script>document.addEventListener("DOMContentLoaded", function () {
        var profileButton = document.getElementById("profileButton");
        var profileDropdown = document.getElementById("profile");
    
        profileButton.addEventListener("click", function (event) {
            event.preventDefault();
            profileDropdown.classList.toggle("active");
        });
    });
    </script>
    
</body>
</html>