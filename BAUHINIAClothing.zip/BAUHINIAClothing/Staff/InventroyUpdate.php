<?php
    include('inc/security.php');

    $Productid = $_GET["Product_ID"];
    $res = mysqli_query($connection, "SELECT * FROM product WHERE Product_ID = '$Productid'");
    if ($row = mysqli_fetch_array($res)) {
        $productname = $row['Product_Name'];
        $qunaity = $row['Quantity'];
        $Category = $row['Category'];
        $price = $row['Price'];
        $currentImage = $row['Image']; 
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Inventory</title>
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/updateinventory.Css">
    <link rel="stylesheet" href="css/footer.css">  
    <script src="script.js"></script> 
</head>
<body>
    <div class="container">
        <nav>
            <div>
                <nav>
                    <img src="images/logo.png" style="width: 200px; height: 70px;filter:brightness(55%)">
                    <ul class="nav__list">
                        <li class="nav__item">
                            <a href="#profile" id="profileButton">
                                <img src="images/profile.png" style="width: 25px; height: 25px; padding-top: 10px;">
                            </a>
                            <div id="profile" class="nav_dropdown">
                                <a href="">Profile</a>
                                <a href="staffsignup.html">Log Out</a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <hr>
            </div> 
        </nav>
    
        <div class="center">
            <h1>Update Inventory</h1>
            <hr>
            <br>
            <form action="inc/Inventory.php" method="POST" enctype="multipart/form-data">
                <div class="row1">
                    <div class="col3">Product ID
                        <div class="col3"><input type="text" required placeholder="Enter Product ID" name="Prod_ID" value="<?php echo $Productid ?>"></div>
                    </div>
                    <div class="col3">Product Name
                        <div class="col3"><input type="text" required placeholder="Enter Product Name"  name="Prod_Name" value="<?php echo $productname ?>"></div>
                    </div>
                    <div class="col3">Price
                        <div class="col3"><input type="text" required placeholder="Enter Price"  name="Price" value="<?php echo $price ?>"></div>
                    </div>
                </div>

                <div class="row1">
                    <div class="col3">Quantity
                        <div class="col1"><input type="text" required placeholder="Enter Quantity" name="Quantity" value="<?php echo $qunaity ?>"></div>
                    </div>
                    <div class="col3">New Image (Optional)<br>
                        <input type="file" name="image" id="image" accept="image/*">
                    </div>
                    <div class="col3">Category
                        <div class="col3">
                            <select name="Category" class="Select" >
                                <option><?php echo $Category ?></option>
                                <option>Men</option>
                                <option>Women</option>
                                <option>Kids</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row1">
                <div class="col3"></div>
                <div class="col3">Current Image<br>
                        <?php
                            if (!empty($currentImage)) {
                                echo '<img src="data:image/jpeg;base64,'.base64_encode($currentImage).'" alt="Current Image" style="max-width: 200px; max-height: 200px;">';
                            } else {
                                echo 'No image available.';
                            }
                        ?>
                    </div>

 
                    <div class="col3"></div>

                </div>

                <input class="submit" type="Submit" Value="Update" name="updatebtn">
            </form>
        </div>
    
        <div class="Footer">
            <div class="left">
                <img src="images/logo.png" style="width: 200px; height: 70px; margin-top: 15px; filter:brightness(90%);">
            <p>
                Complete your style with awesome clothes from us.
                <br><br>
                
                <img src="images/faceboook .png" class="social">
                <img src="images/instagram.gif"  class="social">
                <img src="images/Twiter.png"  class="social">
                <img src="images/Linkedin.png"  class="social">
    
            </p>
            </div>
    
            <div class="right">
                <table>
                   <tr>
                    <td>
                        <th>Company</th>
                    </td>
                    <td>
                        <th>Quick Links</th>
                    </td>
                    <td>
                        <th>Legal</th>
                    </td>
                   </tr>
    
                   <tr>
                    <td>
                        <th><a href="">About Us</a></th>
                    </td>
                    <td>
                        <th><a href="">Share Location</a></th>
                    </td>
                    <td> 
                        <th><a href="">Terms & Condition</a></th>
                    </td>
                   </tr>
    
                   <tr>
                    <td>
                        <th><a href="">Contact Us</a></th>
                    </td>
                    <td>
                        <th><a href="">Order Tracking</a></th>
                    </td>
                    <td> 
                        <th><a href="">Privacy Policy</a></th>
                    </td>
                   </tr>
    
                   <tr>
                    <td>
                        <th><a href="">Support</a></th>
                    </td>
                    <td>
                        <th><a href="">Size Guide</a></th>
                    </td>              
                   </tr>
    
                   <tr>
                    <td>
                        <th><a href="">Careers</a></th>
                    </td>
                    <td>
                        <th><a href="">FAQs</a></th>
                    </td>
                   </tr>
    
                </table>
            </div>
    
    
            <div class="copy">
               <p> Copyright@BAUHINIA2022</p>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            var profileButton = document.getElementById("profileButton");
            var profileDropdown = document.getElementById("profile");

            profileButton.addEventListener("click", function (event) {
                event.preventDefault();
                profileDropdown.classList.toggle("active");
            });
        });
    </script>
    
</body>
</html>
