    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Production</title>
        <link rel="stylesheet" href="css/nav.css">
        <link rel="stylesheet" href="css/footer.css">  
        <link rel="stylesheet" href="css/production.css">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div>
            <div>
                <nav>
                    <img src="images/logo.png" style="width: 200px; height: 70px;filter:brightness(55%)">
                    <ul class="nav__list">
                        <li class="nav__item">
                            <a href="#profile" id="profileButton">
                                <img src="images/profile.png" style="width: 25px; height: 25px; padding-top: 10px;">
                            </a>
                            <div id="profile" class="nav_dropdown">
                                <a href="">Profile</a>
                                <a href="StaffLogin.php">Log Out</a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <hr>
            </div>  
            <div>
                <form action="">
                    <div class="center">
                        <div class="row1">
                            <div class="col2">
                                Product Available <span class="line">&#124</span> <label class="lable" id="lable1">0</label>
                            </div>
                            <div class="col2">
                                Pending Orders <span class="line">&#124</span> <label class="lable" id="lable2">0</label>
                            </div>
                        </div>
                    </div>

                    <hr style="color:lightgray; opacity: 0.5;">

                    <div class="product">
                        <h1>Product Availbe</h1>
                      <!--  <div>
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">Product</th>
                                        <th scope="col">Quantity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr >
                                        <td>Product A</td>
                                        <td>10</td>
                                    </tr>
                                    <tr>
                                        <td>Product B</td>
                                        <td>5</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>-->
                    

                        <input class="submit" type="button" id="generateReportButton" value="Generate report">
                    </div>

                <hr style="color:lightgray; opacity: 0.5; margin-top: 220px;">
                <div class="product">
                    <h1>Orders</h1>
                   <!-- <div>
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Customer ID</th>
                                    <th scope="col">Quantity</th>
                                    <th scope="col">Ordered Product</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr >
                                    <td>O1</td>
                                    <td>Cu10</td>
                                    <td>10</td>
                                    <td>Product A</td>
                                </tr>
                                <tr>
                                    <td>O2</td>
                                    <td>Cu11</td>
                                    <td>10</td>
                                    <td>Product B</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>-->
                    <input class="submit" type="button" id="generatePendingOrdersButton" value="Generate Report" style="margin-top: 10px; margin-bottom: 10px;">

                </div>
                </form>

            </div>
    
            <!--Footer-->
            <div class="Footer">
                <div class="left">
                    <img src="images/logo.png" style="width: 200px; height: 70px; margin-top: 15px;  ">
                <p>
                    Complete your style with awesome clothes from us.
                    <br><br>
                    <a href="https://web.facebook.com/?_rdc=1&_rdr"><img src="images/faceboook .png" class="social"></a>   
                    <a href="https://www.instagram.com/accounts/login/"><img src="images/instagram.gif"  class="social"></a>
                    <a href="https://twitter.com/"><img src="images/Twiter.png"  class="social"></a>
                    <a href="https://www.linkedin.com/"><img src="images/Linkedin.png"  class="social"></a>           
                </p>
                </div>

                <div class="right">
                    <table>
                    <tr>
                        <td>
                            <th>Company</th>
                        </td>
                        <td>
                            <th>Quick Links</th>
                        </td>
                        <td>
                            <th>Legal</th>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <th><a href="">About Us</a></th>
                        </td>
                        <td>
                            <th><a href="">Share Location</a></th>
                        </td>
                        <td> 
                            <th><a href="">Terms & Condition</a></th>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <th><a href="">Contact Us</a></th>
                        </td>
                        <td>
                            <th><a href="">Order Tracking</a></th>
                        </td>
                        <td> 
                            <th><a href="">Privacy Policy</a></th>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <th><a href="">Support</a></th>
                        </td>
                        <td>
                            <th><a href="">Size Guide</a></th>
                        </td>              
                    </tr>

                    <tr>
                        <td>
                            <th><a href="">Careers</a></th>
                        </td>
                        <td>
                            <th><a href="">FAQs</a></th>
                        </td>
                    </tr>

                    </table>
                </div>


                <div class="copy">
                <p> Copyright@BAUHINIA2022</p>
                </div>
            </div>
        </div>

        <script>
            document.addEventListener("DOMContentLoaded", function () {
            var generatePendingOrdersButton = document.getElementById("generatePendingOrdersButton");

                generatePendingOrdersButton.addEventListener("click", function () {
                    // Fetch order details
                    fetch('inc/getorder.php')
                        .then(response => response.json())
                        .then(data => {
                            fetch('inc/generateOrdersPDF.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                },
                                body: JSON.stringify(data),
                            })
                            .then(response => response.blob())
                            .then(blob => {
                                var url = window.URL.createObjectURL(blob);
                                // Open the PDF in a new tab
                                window.open(url, '_blank');

                                // Clean up the URL object
                                window.URL.revokeObjectURL(url);
                            })
                            .catch(error => console.error('Error generating orders PDF:', error));
                        })
                        .catch(error => console.error('Error fetching orders details:', error));
                });
            });

        </script>
        <script>
            document.addEventListener("DOMContentLoaded", function () {
            var generateReportButton = document.getElementById("generateReportButton");

                generateReportButton.addEventListener("click", function () {
                    // Fetch product details from the server
                    fetch('inc/getProductDetails.php')
                        .then(response => response.json())
                        .then(data => {
                            // Call a server-side script to generate the PDF
                            fetch('inc/generatePDF.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                },
                                body: JSON.stringify(data),
                            })
                            .then(response => response.blob())
                            .then(blob => {
                                // Create a URL for the PDF blob
                                var url = window.URL.createObjectURL(blob);

                                // Open the PDF in a new tab
                                window.open(url, '_blank');

                                // Clean up the URL object
                                window.URL.revokeObjectURL(url);
                            })
                            .catch(error => console.error('Error generating PDF:', error));
                        })
                        .catch(error => console.error('Error fetching product details:', error));
                });
            });
        </script>
        <script>
            document.addEventListener("DOMContentLoaded", function () {
            // Fetch total product quantity from the server
            fetch('inc/getquantity.php')
                .then(response => response.json())
                .then(data => {
                    // Update the product quantity in the HTML
                    const productQuantityElement = document.querySelector('.col2 #lable1');
                    if (productQuantityElement) {
                        productQuantityElement.textContent = data.totalQuantity;
                    }
                })
                .catch(error => {
                    console.error('Error fetching product quantity:', error);
                    console.log('Response status:', error.status);
                    console.log('Response text:', error.statusText);
                });

            // Fetch total orders from the server
            fetch('inc/orders.php')
                .then(response => response.json())
                .then(data => {
                    // Update the product quantity in the HTML
                    const productQuantityElement = document.querySelector('.col2 #lable2');
                    if (productQuantityElement) {
                        productQuantityElement.textContent = data.orders;
                    }
                })
                .catch(error => {
                    console.error('Error fetching product quantity:', error);
                    console.log('Response status:', error.status);
                    console.log('Response text:', error.statusText);
                });

            var profileButton = document.getElementById("profileButton");
            var profileDropdown = document.getElementById("profile");

            profileButton.addEventListener("click", function (event) {
                event.preventDefault();
                profileDropdown.classList.toggle("active");
            });
        });
    </script>
    </body>
</html>