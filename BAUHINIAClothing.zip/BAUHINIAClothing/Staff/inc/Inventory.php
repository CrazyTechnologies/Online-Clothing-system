<?php
include('security.php');

if (isset($_POST['Addbtn'])) {
    $Productid = $_POST['Prod_ID'];
    $productname = $_POST['Prod_Name'];
    $price = $_POST['Price'];
    $qunaity = $_POST['Quantity'];
    $Category=$_POST['Category'];

    $check_product_id_query = "SELECT * FROM product WHERE Product_ID = '{$Productid}'";
    $check_product_id_query = mysqli_query($connection, $check_product_id_query);

    if (mysqli_num_rows($check_product_id_query) > 0) {
        // product ID already exists
        echo '<script>alert("Product ID already exists.");</script>';
        echo '<script>location.href="../InventoryManagment.php";</script>';
        exit();
    }

    // Check if a file was uploaded
    if (isset($_FILES['image'])) {
        $image = $_FILES['image']['tmp_name']; 
        $imageContent = addslashes(file_get_contents($image)); 

        // Staff ID and Email don't exist, proceed with insertion
        $query = "INSERT INTO product(`Product_ID`, `Product_Name`, `Price`, `Quantity`, `Category`, `Image`) VALUES ('$Productid', '$productname', '$price', '$qunaity','$Category', '$imageContent')";
        mysqli_query($connection, $query);

        echo '<script>alert("Product added successfully.");</script>';
        echo '<script>location.href="../InventoryManagment.php";</script>';
        exit();
    } else {
        echo '<script>alert("Invalid file submission.");</script>';
        echo '<script>location.href="../InventoryManagment.php";</script>';
        exit();
    }    
}

if (isset($_POST['updatebtn'])) {
    $Productid = $_POST['Prod_ID'];
    $productname = $_POST['Prod_Name'];
    $price = $_POST['Price'];
    $qunaity = $_POST['Quantity'];
    $Category = $_POST['Category'];

    // Check if a new image is provided
    if (isset($_FILES['image']) && !empty($_FILES['image']['tmp_name'])) {
        $newImage = $_FILES['image']['tmp_name'];
        $imageContent = addslashes(file_get_contents($newImage));
        $updateImageQuery = "UPDATE product SET Image='{$imageContent}' WHERE Product_ID='{$Productid}'";
        mysqli_query($connection, $updateImageQuery);
    }

    // Update other product details
    $updateQuery = "UPDATE product SET Product_Name='{$productname}', Price='{$price}', Quantity='{$qunaity}', Category='{$Category}' WHERE Product_ID='{$Productid}'";
    mysqli_query($connection, $updateQuery);

    echo '<script>alert("Product updated successfully.");</script>';
    echo '<script>location.href="../InventoryManagment.php";</script>';
}

?>
