<?php
include('security.php');

$PID=$_GET["Product_ID"];

mysqli_query($connection,"DELETE FROM product WHERE Product_ID ='{$PID}'");

echo '<script>alert("Product deleted successfully.");</script>';
echo '<script>location.href="../InventoryManagment.php";</script>';
exit();
?>