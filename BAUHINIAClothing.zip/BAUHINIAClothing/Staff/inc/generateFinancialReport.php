<?php
require_once("../TCPDF-main/tcpdf.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Get selected month from the request body
        $postData = json_decode(file_get_contents('php://input'), true);
        $selectedMonth = $postData['selectedMonth'];

   
        include('security.php');


        $stmt = $connection->prepare("SELECT Date, Amount FROM orders WHERE MONTH(Date) = MONTH(?)");
        $stmt->bind_param('s', $selectedMonth);
        $stmt->execute();

        $result = $stmt->get_result();

        // Create a new TCPDF instance
        $pdf = new TCPDF('p', 'mm', 'A4');
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
        $pdf->AddPage();

        // Set font
        $pdf->SetFont('helvetica', '', 12);

        // Add centered heading
        $pdf->WriteHTML('<div style="text-align:center;"><h1>Income Report for ' . date("F Y", strtotime($selectedMonth)) . '</h1></div><br><hr>');

        // Add table with report details
        $html = '<table border="1">';
        $html .= '<thead><tr><th>Date</th><th>Amount</th></tr></thead><tbody>';

        while ($row = $result->fetch_assoc()) {
            $html .= '<tr>';
            $html .= '<td style="padding: 10px; border: 1px solid #dddddd; text-align: center;">' . $row['Date'] . '</td>';
            $html .= '<td style="padding: 10px; border: 1px solid #dddddd; text-align: center;">' . $row['Amount'] . '</td>';
            $html .= '</tr>';
        }

        $html .= '</tbody></table>';

        // Clean the output buffer
        ob_clean();

        $pdf->WriteHTML($html);

        // Save the PDF file
        $pdfFileName = 'income_report_' . date('Y-m', strtotime($selectedMonth)) . '.pdf';
        $pdf->Output($pdfFileName, 'F');

        // Respond with the PDF file name
        $response = ['pdfUrl' => $pdfFileName];
        header('Content-Type: application/json');
        echo json_encode($response);

        // Close the database connection
        $stmt->close();
        $connection->close();
    } catch (Exception $e) {
        // Handle exceptions here
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(['error' => 'Internal Server Error']);
    }
} else {
    // If not a POST request, return an error message
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => 'Invalid request']);
}
?>
