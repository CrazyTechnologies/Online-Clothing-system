<?php
require_once("../TCPDF-main/tcpdf.php");

// Check if data is received via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get JSON data from the request body
    $postData = json_decode(file_get_contents('php://input'), true);

    // Check if the 'products' key is present in the received data
    if (isset($postData['products']) && is_array($postData['products'])) {
        // Create a new TCPDF instance
        $pdf = new TCPDF('p', 'mm', 'A4');
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);

        $pdf->AddPage();

        // Set font
        $pdf->SetFont('helvetica', '', 12);

        // Add centered heading
        $pdf->WriteHTML('<div style="text-align:center;"><h1>BAUHINIA CLOTHINGS Daily Orders Report</h1></div><br><hr>');

        // Add table with order details
        $html = '<table style="border-collapse: collapse; width: 100%;" border="1">';
        $html .= '<thead><tr style="background-color: #f2f2f2; text-align: center;">';
        $html .= '<th style="padding: 10px; border: 1px solid #dddddd;">Order ID</th>';
        $html .= '<th style="padding: 10px; border: 1px solid #dddddd;">Customer ID</th>';
        $html .= '<th style="padding: 10px; border: 1px solid #dddddd;">Date</th>';
        $html .= '</tr></thead><tbody>';

        // Check if 'products' is not null before using foreach
        foreach ($postData['products'] as $order) {
            $html .= '<tr>';
            $html .= '<td style="padding: 10px; border: 1px solid #dddddd; text-align: left;">' . $order['oid'] . '</td>';
            $html .= '<td style="padding: 10px; border: 1px solid #dddddd; text-align: center;">' . $order['cid'] . '</td>';
            $html .= '<td style="padding: 10px; border: 1px solid #dddddd; text-align: center;">' . $order['date'] . '</td>';
            $html .= '</tr>';
        }

        $html .= '</tbody></table>';

        // Clean the output buffer
        ob_clean();

        $pdf->WriteHTML($html);

        // Output the PDF
        $pdf->Output();
    } else {
        // Debugging: Output the received data for inspection
        echo 'Received Data: ' . json_encode($postData);
        // If 'products' key is not present or is not an array, return an error message
        echo 'Invalid data format';
    }
} else {
    // If not a POST request, return an error message
    echo 'Invalid request';
}
?>
