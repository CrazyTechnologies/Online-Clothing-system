<?php
require_once("../TCPDF-main/tcpdf.php");

// Check if data is received via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get JSON data from the request body
    $postData = json_decode(file_get_contents('php://input'), true);

    // Create a new TCPDF instance
    $pdf = new TCPDF('p', 'mm', 'A4');
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    $pdf->AddPage();

    // Set font
    $pdf->SetFont('helvetica', '', 12);

    // Add centered heading
    $pdf->WriteHTML('<div style="text-align:center;"><h1>BAUHINIA CLOTHINGS Daily Product Report</h1></div><br><hr>');

    // Add table with product details
    $html = '<table style="border-collapse: collapse; width: 100%;" border="1">';
    $html .= '<thead><tr style="background-color: #f2f2f2; text-align: center;">';
    $html .= '<th style="padding: 10px; border: 1px solid #dddddd;">Product</th>';
    $html .= '<th style="padding: 10px; border: 1px solid #dddddd;">Quantity</th>';
    $html .= '</tr></thead><tbody>';
    
    foreach ($postData['products'] as $product) {
        $html .= '<tr>';
        $html .= '<td style="padding: 10px; border: 1px solid #dddddd; text-align: left;">' . $product['name'] . '</td>';
        $html .= '<td style="padding: 10px; border: 1px solid #dddddd; text-align: center;">' . $product['quantity'] . '</td>';
        $html .= '</tr>';
    }
    
    $html .= '</tbody></table>';
    
    
    $pdf->WriteHTML($html);

    // Output the PDF
    $pdf->Output();
} else {
    // If not a POST request, return an error message
    echo 'Invalid request';
}
?>
