<?php
include('security.php');

// Query to get product details
$sql = "SELECT Product_Name, Quantity FROM product";
$result = $connection->query($sql);

$productDetails = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $productDetails[] = [
            'name' => $row['Product_Name'],
            'quantity' => $row['Quantity'],
        ];
    }
}

// Close the database connection
$connection->close();

// Set the content type to JSON
header('Content-Type: application/json');

// Return product details as JSON
echo json_encode(['products' => $productDetails]);

?>
