<?php
include('security.php');

// Query to get product details
$sql = "SELECT Order_ID, Customer_ID,Date FROM orders";
$result = $connection->query($sql);

$productDetails = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $productDetails[] = [
            'oid' => $row['Order_ID'],
            'cid' => $row['Customer_ID'],
            'date' => $row['Date'],
        ];
    }
}

// Close the database connection
$connection->close();

// Set the content type to JSON
header('Content-Type: application/json');

// Return product details as JSON
echo json_encode(['products' => $productDetails]);

?>
