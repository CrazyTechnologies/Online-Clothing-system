<?php
include('security.php');

// Query to get the sum of product quantities
$sql = "SELECT SUM(Quantity) AS total_quantity FROM product";
$result = $connection->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalQuantity = $row['total_quantity'];
} else {
    $totalQuantity = 0;
}

// Close the database connection
$connection->close();

// Set the content type to JSON
header('Content-Type: application/json');

// Return the total quantity as JSON
echo json_encode(['totalQuantity' => $totalQuantity]);
?>
