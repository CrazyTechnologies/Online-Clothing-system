<?php
include('security.php');

if (isset($_POST['login_btn'])) {
    $StaffID = $_POST['StaffID'];
    $email = $_POST['Email'];
    $password = $_POST['staffpassword'];

    $query = "SELECT * FROM staff WHERE Staff_ID ='$StaffID' AND Email='$email' LIMIT 1";
    $query_run = mysqli_query($connection, $query);

    if (!$query_run) {
       
        echo 'Error executing the query: ' . mysqli_error($connection);
    } else {
        $userTypes = mysqli_fetch_assoc($query_run);

        if ($userTypes) {
            // User exists
            $hashed_password = $userTypes['staffpassword'];

            // Verify the hashed password
            if (password_verify($password, $hashed_password)) {
                // Password is correct
                if ($userTypes['Designation'] == "Cheif Accountant") {
                    $_SESSION['Staff_ID'] = $StaffID;
                    header('Location:../Accounts.php');
                } elseif ($userTypes['Designation'] == "Inventory Clerk") {
                    $_SESSION['Staff_ID'] = $StaffID;
                    header('Location:../InventoryManagment.php');
                } elseif ($userTypes['Designation'] == "Production Manager") {
                    $_SESSION['Staff_ID'] = $StaffID;
                    header('Location:../Production.php');
                } else {
                    $_SESSION['status'] = "Email / Password is Invalid";
                    echo '<script>alert("Email / Password is Invalid.");</script>';
                    echo '<script>location.href="../StaffLogin.php";</script>';
                    exit();
                }
            } else {
                // Password is incorrect
                $_SESSION['status'] = "Email / Password is Invalid";
                echo '<script>alert("Email / Password is Invalid.");</script>';
                echo '<script>location.href="../StaffLogin.php";</script>';
                exit();
            }
        } else {
            // User does not exist
            echo '<script>alert("User does not exist.");</script>';
            echo '<script>location.href="../StaffLogin.php";</script>';
        }
    }
}
?>
