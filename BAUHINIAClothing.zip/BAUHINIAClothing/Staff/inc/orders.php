<?php
include('security.php');

// Query to get the count of orders
$sql = "SELECT COUNT(Order_ID) AS totalOrders FROM orders";
$result = $connection->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $orders = $row['totalOrders'];
} else {
    $orders = 0;
}

// Close the database connection
$connection->close();

// Set the content type to JSON
header('Content-Type: application/json');

// Return the total orders as JSON
echo json_encode(['orders' => $orders]);
?>
