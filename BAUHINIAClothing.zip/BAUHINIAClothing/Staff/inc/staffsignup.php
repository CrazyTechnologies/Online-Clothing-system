<?php
    include('security.php');

    if(isset($_POST['submi_btn'])){

        $Staff_ID = $_POST['Staff_ID'];
        $Designation = $_POST['Designation'];
        $contact = $_POST['contact'];
        $email = $_POST['email'];
        $password = $_POST['staffpassword'];
        $confirm_password = $_POST['confirm_password'];

        // Check if passwords match
        if ($password != $confirm_password) {
            echo '<script>alert("Passwords do not match.");</script>';
            echo '<script>location.href="../staffsignup.php";</script>';
            exit();
        }

        // Hash the password before storing it in the database
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Check if the staff ID already exists in the database
        $check_staff_id_query = "SELECT * FROM staff WHERE Staff_ID = '{$Staff_ID}'";
        $check_staff_id_result = mysqli_query($connection, $check_staff_id_query);

        if (mysqli_num_rows($check_staff_id_result) > 0) {
            // Staff ID already exists
            echo '<script>alert("Staff ID already exists.");</script>';
            echo '<script>location.href="../staffsignup.php";</script>';
            exit();
        }

        // Check if the email already exists in the database
        $check_email_query = "SELECT * FROM staff WHERE Email = '{$email}'";
        $check_email_result = mysqli_query($connection, $check_email_query);

        if (mysqli_num_rows($check_email_result) > 0) {
            // Email already exists
            echo '<script>alert("Email already exists.");</script>';
            echo '<script>location.href="../staffsignup.php";</script>';
            exit();
        }

        // Staff ID and Email don't exist, proceed with insertion
        $query = "INSERT INTO staff(`Staff_ID`, `Designation`, `Contact_Num`, `Email`, `staffpassword`) VALUES ('{$Staff_ID}', '{$Designation}', '{$contact}', '{$email}', '{$hashed_password}')";

        mysqli_query($connection, $query);

        echo '<script>alert("Signup successful.");</script>';
        echo '<script>location.href="../StaffLogin.php";</script>';
        exit();
    } 
    else {
        echo '<script>alert("Invalid form submission.");</script>';
        echo '<script>location.href="../staffsignup.php";</script>';
        exit();
    }
?>
